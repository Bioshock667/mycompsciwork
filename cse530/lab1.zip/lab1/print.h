#include <iostream>

void print(double input);
