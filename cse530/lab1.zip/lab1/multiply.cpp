double multiply(double m1, double m2) {return m1 * m2;}
