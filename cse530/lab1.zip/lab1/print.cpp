#include <iostream>

void print(double input) {std::cout << "Product: " << input << std::endl;}
