double multiply(double m1, double m2);
